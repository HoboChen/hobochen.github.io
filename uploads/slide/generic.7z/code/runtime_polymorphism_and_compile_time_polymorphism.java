package com.company;

public class Main {

    public static void main(String[] args) {
        Box<Integer> foo = new FooBox(1, 2);
        Box<Integer> bar = new BarBox(3, 4);
        System.out.println(foo.get() * bar.get());
    }

}

abstract class Box<T> {
    public T foo;
    public T bar;

    Box() {}

    public Box(T foo, T bar) {
        this.foo = foo;
        this.bar = bar;
    }

    abstract public T get();
}

class FooBox<T> extends Box<T> {

    FooBox(T foo, T bar) {
        super(foo, bar);
    }

    public T get() {
        return super.foo;
    }
}

class BarBox<T> extends Box<T> {

    BarBox(T foo, T bar) {
        super(foo, bar);
    }

    public T get() {
        return super.bar;
    }
}
