template<typename T>
struct IBasket {
    T foo;
    T bar;
    IBasket(const T& foo, const T& bar) : foo(foo), bar(bar) { }
    virtual T get() = 0;
};

template <typename T>
struct FooBasket : public IBasket<T> {

    FooBasket(const T& foo, const T& bar) : IBasket<T>(foo, bar) { }

    T get() override {
        return IBasket<T>::foo;
    }
};

template <typename T>
struct BarBasket : public IBasket<T> {

    BarBasket(const T& foo, const T& bar) : IBasket<T>(foo, bar) { }
    
    T get() override {
        return IBasket<T>::bar;
    }
};

int test() {
    FooBasket<int> fb(1, 2);
    BarBasket<int> bb(3, 4);
    IBasket<int>* fbi = dynamic_cast<IBasket<int>*>(&fb);
    IBasket<int>* bbi = dynamic_cast<IBasket<int>*>(&bb);
    return fbi->get() * bbi->get();
}
