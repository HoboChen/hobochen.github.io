template<typename T>
struct Box {
    T t;
};

// if there is Box<int>, then the compiler will generate a struct like
struct Box_int {
    int t;
};

// if there is Box<std::string> as well, then
struct Box_string {
    std::string t;
}
