public class Main {

    public static void main(String[] args) {
        Box rawBox = new Box("hello");
        Box<Integer> integerBox = rawBox;
        System.out.println(5 + integerBox.get()); // it compiles well
    }
}

class Box<T> {
    T t;

    Box(T t) {
        this.t = t;
    }

    T get() {
        return t;
    }
}
