template<typename T>
struct Box {
    T t;

    Box(const T& t) : t(t) { }

    T get() {
       return t;
    } 
};

template<>
struct Box<long long> {
    bool t;
};

void test() {
    Box<int> foo(5);
    Box<double> bar(3.1416);
    Box<long long> foobar;
}
