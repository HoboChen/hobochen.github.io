class Box<T> {
    T t;

    Box(T t) {
        this.t = t;
    }

    T get() {
        return t;
    }
}

public class Main {

    public static void main(String[] args) {
        Box<Integer> integerBox = new Box<Integer>(2147482647);
        System.out.println(integerBox.get());
    }

}

// after compiling to byte code, there is only

class Box {
    Object t;

	Box(Object t) {
        this.t = t;
    }

    Object get() {
        return t;
    }
};

// and the main becomes:

public class Main {
    public static void main(String[] args) {
        Box integerBox = (Object)new Integer(2147483647);
        System.out.println((Integer)integerBox.get());
    }
}
